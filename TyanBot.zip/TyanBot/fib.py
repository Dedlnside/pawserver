import datetime as dt
import sys

def fibonacci(n):
	a, b = 0, 1
	for _ in range(n):
		yield(a)
		a, b = b, a + b

def main(qte):
	fibo_list = [None] * qte
	g = fibonacci(qte)
	
	for i in range(qte):
		fibo_list[i] = (next(g))
	
	return fibo_list