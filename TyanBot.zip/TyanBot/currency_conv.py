from currency_converter import CurrencyConverter

cc = CurrencyConverter()

def convert(frm, to, value):
	return cc.convert(value, frm, to)