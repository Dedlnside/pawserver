from youtube_transcript_api import YouTubeTranscriptApi as yta
from pytube import YouTube
from random import randint as rnd
def get(vid_url):
	video = YouTube(url=vid_url)
	f_id = rnd(999,9999)
	video_info = {
		'info': video.vid_info,
		'file_id': f_id
	}
	with open(f"dated_files/{f_id}.txt", "w+", encoding="utf-8") as f:
		transcript_list = yta.get_transcript(video.video_id, languages=['ru', 'en'])
		
		for i in transcript_list:
			f.write(i['text'] + '\n')
			print(i["text"])
	return video_info