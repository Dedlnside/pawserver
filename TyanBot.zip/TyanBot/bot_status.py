from datetime import datetime
age = 14
name = "Тян"