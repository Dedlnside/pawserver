#qrgen
import qrcode
from random import randint as rnd
def mkqr(text):
	id = rnd(1111,9999)
	filepath = f'img/{id}.png'
	
	img = qrcode.make(text)
	
	img.save(filepath)
	
	return id