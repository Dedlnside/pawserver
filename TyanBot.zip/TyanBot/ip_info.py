from ipwhois import IPWhois

def get(ip):
	info = IPWhois(ip).lookup_whois()['nets'][0]
	result = ""
	for key in info:
		result += str(key+": " + str(info[key]) + "\n")
	print(result)
	return result