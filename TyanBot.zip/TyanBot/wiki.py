from wikipedia import wikipedia

wikipedia.set_lang("ru")
def search(text):
	try:
		return(wikipedia.summary(text, sentences=3))
	except:
		return "Я не нашла информации!!!"