import requests

def get(url):
	