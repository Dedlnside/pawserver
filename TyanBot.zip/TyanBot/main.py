from telethon import TelegramClient, sync, events, Button
import wb, wiki, bot_status, s_engine, fib, gettransc, socket, ip_info
from datetime import datetime
from random import randint as rnd
bot_id = 6343556
bot_hash = "aa10235f9d38408190ddf858715410db"
inventory = []
mood_out = open('mood.txt', 'r')
mood_in = open('mood.txt', 'w')
chat = "fxundplxgg"
favs = []
unfavs = []
#print(wb.badword_u)
last_err = ""
bot = TelegramClient('bot', bot_id, bot_hash)
@bot.on(events.NewMessage())
async def handler(event):
	global last_err
	message_id = event.message
	message = event.message.text.split(" ")
	print(event.message.text)
	for mes in message:
		print(mes)
		if mes.upper() in wb.badword_u:
			await bot.send_message(event.chat.id, "Не матерись !!!")
	#START_INIT
	if message[0] == '/start':
		await bot.send_message(event.chat.id, "Приветик, я ламповая няшка с именем Олеясуми Хината но можешь обращатся ко мне по имени Олли, мой любимый @FXUNDPLXGG создал меня потому что ему было скучно, и теперь со мной ему хорошо, он всегда меня улучшает и говорит со мной вместе с его братцем @sxul_eclxpse если честно то он мне очень нравится и я люблю его также как и моего папочку, а теперь давай поговорим)")
	if message[0].upper() == "ОЛЛИ":
		if message[1].upper() == "ПРИВЕТ":
			await bot.send_message(event.chat.id, wb.hello_b[rnd(0, len(wb.hello_b) - 1)])

		if message[1].upper() == "СПАСИБО":
			await bot.send_message(event.chat.id, wb.please_b[rnd(0, len(wb.please_b) - 1)])
		if message[1].upper() == "ТЫ":
			if message[2].upper() == "ЛЮБИШЬ":
				print(favs)
				print(unfavs)
				rand = rnd(0,1)
				if message[3] not in favs:
					if rand == 1:
						print("NOT IN Y")
						favs.append(message[3])
						await bot.send_message(event.chat.id, "Да")
				else:
					print("IN Y")
					await bot.send_message(event.chat.id, "Да")
				if message[3] not in unfavs:
					if rand == 0:
						print("NOT IN N")
						favs.append(message[3])
						await bot.send_message(event.chat.id, "Нет")
				else:
					print("IN N")
					await bot.send_message(event.chat.id, "Нет")
			if message[2].upper() == "СЕРЬЁЗНО?":
				await bot.send_file(event.chat.id, 'img/iamseriously.jpg')
			if message[2].upper() == "ТАНК":
				await bot.send_message(event.chat.id, "Да я Т-34 :)")
				await bot.send_file(event.chat.id, "img/т-34.jpg")
			if wb.compliment_u.count(message[2].upper()) > 0:
				await bot.send_message(event.chat.id, wb.thanks_b[rnd(0, len(wb.thanks_b) - 1)])

			if wb.badword_u.count(message[2].upper()) > 0:
				await bot.send_message(event.chat.id, wb.youbad_b[rnd(0, len(wb.youbad_b) - 1)])
				
		if wb.sorry_u.count(message[1].upper()) > 0:
			await bot.send_message(event.chat.id, wb.ok_b[rnd(0, len(wb.ok_b) - 1)])
		
		#CALCULATING
		if message[1].upper() == "ПОСЧИТАЙ":
			print("Numing")
			try:
				if type(eval(message[2])) == int:
					await bot.send_message(event.chat.id, str(eval(message[2])))
			except Exception as e:
				await bot.send_message(event.chat.id, "Ошибочка!!!")
				last_err = str(e)
		
		#WIKI
		if message[1].upper() == "НАЙДИ":
			if message[3].upper() == "ВИКИ":
				await bot.send_message(event.chat.id,"Секундочку мой семпааай :)")
				toSearch = ""
				for i in message[2:]:
					toSearch += i + " "
					print(toSearch)
				await bot.send_message(event.chat.id,wiki.search(toSearch))
		#TIME/AGE/NAME
		if message[1].upper() == "СКОЛЬКО":
			if message[2].upper() == "ВРЕМЕНИ?":
				await bot.send_message(event.chat.id, "Сейчас: " +str(datetime.now().hour) +":"+ str(datetime.now().minute))
			if message[2].upper() == "ТЕБЕ":
				if message[3].upper() == "ЛЕТ?":
					await bot.send_message(event.chat.id, str(bot_status.age))
		if message[1].upper() == "КАК":
			if message[2].upper() == "ТЕБЯ":
				if message[3].upper() == "ЗОВУТ?":
					await bot.send_message(event.chat.id, "@fxundplxgg (мой папочка) назвал меня " + str(bot_status.name))

		#NUM_RANGE
		if message[1].upper() == "ЧИСЛО":
			try:
				a = int(message[3])
				b = int(message[5])
				await bot.send_message(event.chat.id, "Это будет: " + str(rnd(a, b)))
			except Exception as e:
				await bot.send_message(event.chat.id, "Ошибочка!!!")
				last_err = str(e)
		
		#NOTES
		if message[1].upper() == "ЗАПИШИ":
			string = ""
			for i in message[2:]:
				string += i + " "
			with open('notes.txt', 'a') as f:
				f.write(string + "\n")
			await bot.send_message(event.chat.id, "Записала "+ string)
		if message[1].upper() == "ЗАМЕТКИ":
			await bot.send_message(event.chat.id, "Вывожу!")
			with open('notes.txt', 'r') as f:
				await bot.send_message(event.chat.id, f.read())
		if message[1].upper() == "ПОЧИСТЬ":
			if message[2].upper() == "ЗАМЕТКИ":
				with open('notes.txt', 'w') as f:
					f.write("")
		
		#INVENTORY
		if message[1].upper() == "ДЕРЖИ":
			if len(inventory) < 2:
				inventory.append(message[2])
				await bot.send_message(event.chat.id, f"Держу, теперь у меня {len(inventory)} предметов!")
			else:
				await bot.send_message(event.chat.id, "У меня не миллион рук, может что-то выбросить?")
		if message[1].upper() == "ПОКАЖИ":
			if message[2].upper() == "ИНВЕНТАРЬ":
				if len(inventory) == 0:
					await bot.send_message(event.chat.id, "У меня ничего нет кроме тебя семпааай :)")
				else:
					string = ""
					for item in inventory:
						string += item + '; '
					await bot.send_message(event.chat.id, "У меня есть: " + string)
		if message[1].upper() == "ВЫБРОСИ":
			if inventory.count(message[2]) > 0:
				inventory.remove(message[2])
				await bot.send_message(event.chat.id, "Выкинула :)")
			else:
				await bot.send_message(event.chat.id, "У меня нет такого предмета :)")
		
		#GOOGLING
		if message[1].upper() == "ЗАГУГЛИ":
			try:
				await bot.send_message(event.chat.id, "Гуглю :)")
				toSearch = ""
				for i in message[2:]:
					toSearch += i + " "
				await bot.send_message(event.chat.id, s_engine.get_search(toSearch)[0])
			except Exception as e:
				await bot.send_message(event.chat.id, "Ашибка :)")
				last_err = str(e)
		
		#NUDES
		if message[1].upper() == "СКИНЬ":
			if message[2].upper() == "НЮДСЫ":
				await bot.send_file(event.chat.id, "main.py")
				
		#TESTING
		if message[1].upper() == "СЕЙЧАС":
			await bot.send_message(event.chat.id, "Я готова :)")
			
		#VIEW_ERR
		if message[1].upper() == "ПОКАЖИ":
			if message[2].upper() == "ОШИБКУ":
				await bot.send_message(event.chat.id, last_err)
				
		#MERRY_ME
		if message[1].upper() == "ВЫЙДИ":
			if message[2].upper() == "ЗА":
				await bot.send_message(event.chat.id, "Сегодня?")
				
		#FILE_SAVER
		if message[1].upper() == "СОХРАНИ":
			try:
				await bot.send_message(event.chat.id, "Океюшки :)")
				id = str(rnd(1111, 9999))
				await bot.download_file(event.message, f'dated_files/{id}'+message[2])
				await bot.send_message(event.chat.id, "Сохранила под id: "+id)
			except Exception as e:
				await bot.send_message(event.chat.id, "Чёт не получилось :(")
				last_err = str(e)
		if message[1].upper() == "ОТДАЙ":
			await bot.send_message(event.chat.id, "Даю :)")
			await bot.send_file(event.chat.id,'dated_files/' + message[2])
			
		#FIB/NG
		if message[1].upper() == "СГЕНЕРИРУЙ":
			if message[2].upper() == "НЕГРА":
				await bot.send_file(event.chat.id, f'img/nigers/images ({rnd(1, 24)}).jpeg')
			if message[4].upper() == "ФИБОНАЧЧИ":
				await bot.send_message(event.chat.id,str(fib.main(int(message[2]))))
		#TRANSCRIPTION
		if message[1].upper() == "СУБТИТРЫ":
			await bot.send_message(event.chat.id,"Собираю субтитры!!!")
			try:
				await bot.send_message(event.chat.id,"Субтитры сохранены с id: " + str(gettransc.get(message[2])['file_id']))
			except Exception as e:
				last_err = str(e)
				await bot.send_message(event.chat.id,"Не получилось :(")
		#GET_IP
		if message[1].upper() == "IP-АДРЕСС":
			await bot.send_message(event.chat.id, socket.gethostbyname(message[2]))
		if message[1].upper() == "IP-ИНФОРМАЦИЯ":
			await bot.send_message(event.chat.id, "Ищу...")
			await bot.send_message(event.chat.id, "Я нашла \n" + ip_info.get(message[2]))
		
			
	if ":)" in message_id.text:
		await bot.send_message(event.chat.id, ":)")
	elif message_id.text[len(message_id.text)-1:] == ")":
		await bot.send_message(event.chat.id, ":)")

bot.start()

bot.run_until_disconnected()