from googlesearch import search
def get_search(uquery):
	result = []
	for i in search(query=uquery, tld='ru', lang='ru', start=1, stop=2):
		result.append(i)
	return result