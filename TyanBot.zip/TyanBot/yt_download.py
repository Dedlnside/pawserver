from pytube import YouTube

def download(id):
	yt = YouTube("https://youtu.be/" + id)
	stream = yt.streams.filter(only_audio=True).first()
	stream.download()
	return yt.title