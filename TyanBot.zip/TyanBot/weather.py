from pyowm import owm
from pyowm.utils.config import get_default_config

config_dict = get_default_config()
config_dict['language'] = 'ru'

api = owm.OWM("c7fffab842361dbc8d4ebc63f35ff15d", config_dict)

def get_weather(city):
	return api.weather_manager().weather_at_place(city).weather.status
print(get_weather("Ukraine, Kiyv"))